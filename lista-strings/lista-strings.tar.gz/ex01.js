


function reverseString(str) {
    return str.split('').reverse().join('');
    

    
}








console.log(reverseString("Ralielly")); 
console.log(reverseString("Silva")); 